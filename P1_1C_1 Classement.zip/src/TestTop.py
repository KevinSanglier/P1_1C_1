#!/usr/bin/python3
# -*- coding: utf-8 -*-

import unittest
import sys

import CorrTop as correct
import top as student


class TestTop(unittest.TestCase):

    def test0_vide(self):
        k = 0
        text = "vous êtes le bienvenu à jumanji"
        rep = _("Votre fonction doit retourner une liste vide avec k = (0).")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep)

    def test1_simple(self):
        k = 3
        text = "vous êtes le bienvenu à jumanji"
        rep = _("Votre fonction a retourné une mauvaise réponse avec k = ({}) et text = ({}).")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep.format(k, text))
        
    def test2_majuscule(self):
        k = 4
        text = "Vous êtes le bienvenu à Jumanji"
        rep = _("Votre fonction a retourné une mauvaise réponse avec k = ({}) et text = ({}). (Tips: Faites attention aux majuscules.)")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep.format(k, text))

    def test3_ponctuation(self):
        k = 5
        text = "Bonjour, vous êtes le bienvenu à Jumanji !"
        rep = _("Votre fonction a retourné une mauvaise réponse avec k = ({}) et text = ({}). (Tips: Faites attention à la ponctuation.)")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep.format(k, text))

    def test4_moyen(self):
        k = 8
        text = "Bonjour aventurier ! Je m'appelle Nigel. Comment vas-tu ?"
        rep = _("Votre fonction a retourné une mauvaise réponse avec k = ({}) et text = ({}). (Tips: Faites attention aux caractères spéciaux.)")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep.format(k, text))

    def test5_difficile(self):
        k = 9
        text = "Bonjour, vous êtes le bienvenu à Jumanji !"
        rep = _("Votre fonction a retourné une mauvaise réponse avec k = ({}) et text = ({}). (Tips: Faites attention à la longueur de la liste.)")
        try:
            student_ans = student.top(k,text)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception [{}: {}] avec k = ({}) et text = ({}).".format(type(e), e, k, text))
        correct_ans = correct.top(k,text)
        self.assertEqual(student_ans, correct_ans, rep.format(k, text))

if __name__ == '__main__':
    unittest.main()