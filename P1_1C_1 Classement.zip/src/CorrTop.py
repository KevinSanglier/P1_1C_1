#!/usr/bin/python3
# -*- coding: utf-8 -*-

def top(k,text):
    """
    Retourne le top k des plus longs mots présents dans un texte (text).
    @Pre: 'text':un texte avec des mots avec majuscules et minuscules ainsi que des signes de ponctuation. 'k':un nombre.
    @Post: Une liste comprenant les k plus longs mots en minuscules.
    """
    k = int(k)
    punc = """!?.,:;"'-(){}[]"""
    list = []
    top = []
    for word in text:
        if word in punc:
            text = text.replace(word, " ")
    for word in text.split()[::-1]:
        if word.lower() not in list:
            list.append(word.lower())
    list2 = sorted(list, key=len)
    for num in range(len(list2)-1,len(list2)-k-1,-1):
        if num < 0:
            top.append('')
        else:
            top.append(list2[num])
    return top