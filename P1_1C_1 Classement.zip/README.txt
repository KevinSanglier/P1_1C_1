#Sanglier Kevin - 28/02/21
La fonction top prend en compte 2 arguments:
- k qui est la taille du classement.
- 'text' qui est le texte à traiter.
La fonction retournera le top k des plus longs mots du texte, tous en minuscules et sans répétitions.
Si k est plus haut que le nombre de mots du texte, les emplacements restants doivent être ''.