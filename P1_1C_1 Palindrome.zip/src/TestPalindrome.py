# -*- coding: utf-8 -*-

import unittest
import sys

import CorrPalindrome as correct
import palindrome as student


class TestPalindrome(unittest.TestCase):

    def test0_None(self):
        args = ["kayak", "rotor", "alla"]
        rep = _(
            """La fonction a retourné None avec : {} comme argument. Cela est surement du au fait qu'il manque un 'return' dans votre code. Regardez-y bien :)""")
        for n in args:
            try:
                student_ans = student.palindrome(n)
            except Exception as e:
                self.fail(
                    "Test 1: La fonction a provoqué une exception {}: {} avec '{}' comme argument".format(type(e), e,
                                                                                                          n))
            self.assertIsNotNone(student_ans, rep.format(n))

    def test1_Palindrome_true(self):
        args = ["kayak", "rotor", "alla", "ere", "azerreza", "njiijn"]
        rep = _(
            """La fonction a retourné {} quand elle est appelée avec {} comme argument. La réponse souhaité etais :'{}'.""")
        for n in args:
            try:
                student_ans = student.palindrome(n)
            except Exception as e:
                self.fail(
                    """Test 2: La fonction a provoqué une exception {}: avec : '{}' comme argument""".format(type(e), e,
                                                                                                             n))
            correct_ans = correct.palindrome(n)
            self.assertEqual(student_ans, correct_ans,
                             rep.format(student_ans, n, correct_ans))

    def test1_Palindrome_false(self):
        args = ["bonjour", "camion", "gourde", "lampe"]
        rep = _(
            """La fonction a retourné {} quand elle est appelée avec {} comme argument. La réponse souhaité etais :'{} car il ne s'agit pas de palindrome.""")
        for n in args:
            try:
                student_ans = student.palindrome(n)
            except Exception as e:
                self.fail(
                    """Test 3: La fonction a provoqué une exception {}: avec : '{}' comme argument""".format(type(e), e,
                                                                                                             n))
            correct_ans = correct.palindrome(n)
            self.assertEqual(student_ans, correct_ans,
                             rep.format(student_ans, n, correct_ans))

    def test1_palindrome_int(self):
        args = [1, 5, -17, 98, 1221, -12, 0]
        rep = _(
            """La fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {} vu que on ne prend en compte que les chaines de charactère.""")
        for n in args:
            try:
                student_ans = student.palindrome(n)
            except Exception as e:
                self.fail(
                    """Test 4: La fonction a provoqué une exception {}: avec: {} comme argument . Seulement les chaines de caractère sont accepté. ils vous faut ecrire une exception qui retourne 'False' quand un nombre est donné.""".format(
                        type(e), e, n))
            correct_ans = correct.palindrome(n)
            self.assertEqual(student_ans, correct_ans,
                             rep.format(student_ans, n, correct_ans))

    def test1_Palindrome_majuscule(self):
        args = ["KaYak", "ROTOr", "aLla", "Ere", "AZerReza", "nJIijn", "JerrEj"]
        rep = _(
            """La fonction a retourné {} quand elle est appelée avec {} comme argument. La réponse souhaité etais :'{}'. Avez-vous bien mit une condition pour eviter les erreurs liée au majuscules et minuscules ?""")
        for n in args:
            try:
                student_ans = student.palindrome(n)
            except Exception as e:
                self.fail(
                    """Test 5: La fonction a provoqué une exception {}: avec : {} comme argument""".format(type(e), e,
                                                                                                           n))
            correct_ans = correct.palindrome(n)
            self.assertEqual(student_ans, correct_ans,
                             rep.format(student_ans, n, correct_ans))


if __name__ == '__main__':
    unittest.main()