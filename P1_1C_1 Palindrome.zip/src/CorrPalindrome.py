def palindrome(text):
    if type(text) == str:
        text = text.lower()
    else:
        return False
    for i in range(len(text)//2):
        if text[i] != text[-i-1]:
            return False

    if len(text) % 2 == 0:
        return text[:len(text)//2]
    else:
        return text[:(len(text) // 2) + 1]