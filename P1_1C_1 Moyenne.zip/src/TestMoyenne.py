#!/usr/bin/python3
# -*- coding: utf-8 -*-

import unittest
import sys

import CorrMoyenne as correct
import moyenne as student


class TestMoyenne(unittest.TestCase):
    
    
    def test_1(self):
        l = [["f1",4,4,10],["f2",2,4],["f3",5]]
        rep = ("Votre fonction a retourné None pour {} comme argument. Il manque peut être un returne.")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        self.assertIsNotNone(student_ans, rep.format(l))    
  
    
    def test_2(self):
        l = [["f1",1,1,1],["f2",10,4,1],["f3",50,50,50]]
        rep = ("Votre fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {}")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        correct_ans = correct.moyenne(l)
        if student_ans != None:
            self.assertEqual(student_ans, correct_ans, rep.format(student_ans, l, correct_ans))
        
        
    
    def test_3(self):
        l = [["f1",1,1,1],["f2",10,4,1],["f3",50,50,50]]
        rep = ("Votre fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {}. \n Vous avez peut être mal calculé les moyennes.")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        correct_ans = correct.moyenne(l)
        if student_ans != None:
            self.assertEqual(student_ans, correct_ans, rep.format(student_ans, l, correct_ans))
        
        
        
        
    def test_4(self):
        l = [["f1",4,4,10],["f2",2,4],["f3",5]]
        rep = ("Votre fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {}. \n Vous avez peut être pas ordoné correctement les moyenne. Il faut les classer de la plus petite à la plus grande moyenne.")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        correct_ans = correct.moyenne(l)
        if student_ans != None:
            self.assertEqual(student_ans, correct_ans, rep.format(student_ans, l, correct_ans))
        
        
    def test_5(self):
        l = [["f1",4,4,4],["f2",4,4,4],["f3",7,7]]
        rep = ("Votre fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {}. \n Vous avez peut être pas ordoné correctement les moyenne. Si plusieurs moyennes sont les mêmes, il faut les replacer dans le même ordre qu'elles apparaissent dans la liste originale.")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        correct_ans = correct.moyenne(l)
        if student_ans != None:
            self.assertEqual(student_ans, correct_ans, rep.format(student_ans, l, correct_ans))


    def test_6(self):
        l = [["f1",4,4,4],["f2",4,4,4],["f3",4,4]]
        rep = ("Votre fonction a retourné {} lorsqu'elle est appelée avec {} comme argument alors que la réponse attendue est {}. \n Vous avez peut être pas ordoné correctement les moyenne.")
        try:
            student_ans = student.moyenne(l)
        except Exception as e:
            self.fail("Votre fonction a provoqué l'exception {}: {} avec comme argument {}".format(type(e), e, l))
        correct_ans = correct.moyenne(l)
        if student_ans != None:
            self.assertEqual(student_ans, correct_ans, rep.format(student_ans, l, correct_ans))
        
        
if __name__ == '__main__':
    unittest.main()
