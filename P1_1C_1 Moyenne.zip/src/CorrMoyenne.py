#!/usr/bin/python3
# -*- coding: utf-8 -*-


def moyenne(lst):
    """
    pre: une liste contenant des liste avec les longeurs des palindromes
    post: retourne une liste de liste ordonnee des moyennes des longeurs des palindromes
    """
    
    liste = []
    sorted_liste = []
    
    for l in lst:
        new = []
        rep = 0
        for i in range(1, len(l)):
            rep += l[i]
            
        rep = rep/(len(l)-1)
        new.append(l[0])
        new.append(rep)
        liste.append(new)

    first = liste[0]
    
    for el in liste:
        if el[1] != first[1]:
            for element in liste:
                if element[1] < first[1]:
                    first = element
            
            last = liste[0]
            for el in liste:
                if el[1] > last[1]:
                    last = el
                    
                    
            sorted_liste.append(first)
            
            
            second = last
            while len(sorted_liste) < len(liste):
                
                for element in liste:
                    if element[1] < second[1] and element != first and element[1] >= first[1]:
                        cnt = 0
                        for k in sorted_liste:
                            if k == element:
                                cnt += 1
                        
                            if cnt == 0:
                                second = element
                         
                sorted_liste.append(second)
                 
                first = second
                second = last
                 
            return sorted_liste
    
    return liste