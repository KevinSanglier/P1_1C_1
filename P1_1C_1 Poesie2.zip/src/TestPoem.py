import unittest

#import Poesie as correct

import poemStudent as student

class Test_Poesie(unittest.TestCase):
    
    def test_empty(self):
        
        try:
            l1, l2 = student.malus_counter("")
        except Exception as e:
            self.fail("Test 1: La fonction a provoqué une exception {}: {} avec '{}' comme argument".format(type(e), e, ""))
        
        #PoesieC = correct.malus_counter("")
        
        
        self.assertEqual(l1, [], "Votre code ne renvoie pas une liste de mot vide dans le cas d'un string vide en entrée")
        self.assertEqual(l2, [], "Votre code ne renvoie pas une liste de fréquence vide dans le cas d'un string vide en entrée")
    
    def test_one_word(self):
        
        #PoesieC = correct.malus_counter("lol")
        l1, l2 = student.malus_counter("lol")
        
        self.assertEqual(l1, ["lol"], "Votre code ne renvoie pas la liste de mot adéquate dans le cas d'un seul mot en entrée")
        self.assertEqual(l2, [1], "Votre code ne renvoie pas la liste de fréquence adéquate dans le cas d'un seul mot en entrée")
    
    def test_one_word_repeated(self):
        
        #PoesieC = correct.malus_counter("lol lol lol lol lol")
        l1, l2 = student.malus_counter("lol lol lol lol lol")
        
        self.assertEqual(l1, ["lol"], "Votre code ne renvoie pas la liste de mot adéquate dans le cas du même mot répété plusieurs fois en entrée")
        self.assertEqual(l2, [5], "Votre code ne renvoie pas la liste de fréquence adéquate dans le cas du même mot répété plusieur fois en entrée")
    
    def test_general(self):
        
        #PoesieC = correct.malus_counter("La belle prairie était belle")
        l1, l2 = student.malus_counter("La belle prairie était belle")
        
        self.assertEqual(l1, ["La", "belle", "prairie", "était"], "Votre code ne renvoie pas la liste de mot adéquate pour la poésie suivante: La belle prairie était belle")
        self.assertEqual(l2, [1, 2, 1, 1], "Votre code ne renvoie pas la liste de fréquence adéquate pour la poésie suivante: La belle prairie était belle")

if __name__ == '__main__':
    unittest.main()
