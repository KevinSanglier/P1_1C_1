def malus_counter(poem):
    
    p = poem.split()
    
    l1 = []
    
    l2 = []
    
    count = 0
    
    for i in range(len(p)):
        
        for j in range(len(p)):
            
            if p[i] == p[j]:
                
                count += 1
        
        if p[i] not in l1:
        
            l1.append(p[i])
                
            l2.append(count)
            
        count = 0
    
    return l1, l2